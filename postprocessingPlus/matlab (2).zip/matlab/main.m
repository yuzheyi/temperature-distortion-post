function main()
    jsonFileName = './config.json';
    % 检查是否存在 template.json 文件
    if isfile(jsonFileName)
        % 读取 JSON 文件内容
        jsonText = fileread(jsonFileName);
        % 解析 JSON 内容
        configData = jsondecode(jsonText);
        % 提示用户选择模式
        % disp('选择运行模式：');
        % disp('1: 运行瞬态后处理 unsteadyPost');
        % disp('2: 运行稳态后处理 multiSteadyPost');
        % disp('3: 运行云图后处理 multiContourPrint');
        % choice = input('请输入模式编号 (1, 2，3): ');
        choice = configData.runMode
        
        %% 构造网格
        run createMesh.m
        % 根据用户选择运行相应的脚本
        switch choice
            case 1
                disp('1: 运行瞬态后处理 unsteadyPost');
                run('unsteadyPost.m');
                
            case 2
                disp('2: 运行稳态后处理 multiSteadyPost');
                run('multiSteadyPost.m');
            case 3
                disp('3: 运行云图后处理 multiContourPrint');
                run('multiContourPrint.m');
            otherwise
                disp('无效选择，runMode只能为 1, 2 或 3。');
        end
    else
        % 如果文件不存在，生成模板
        generate_config();
    end
end